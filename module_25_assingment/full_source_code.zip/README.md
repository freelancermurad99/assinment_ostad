# Payroll Leave Management System

## Technologies
- Laravel 10
- MySQL


## Credentials Manager
- Username:- **manager**
- Password:- **manager**

## Credentials Staff
- Username:- **staff**
- Password:- **staff**
